DROP TABLE CODA.T_LEE_HIERARCHIEEN_LOG CASCADE CONSTRAINTS;

CREATE TABLE CODA.T_LEE_HIERARCHIEEN_LOG
(
  RUN       NUMBER(5)                           NOT NULL,
  RUN_DATE  DATE                                NOT NULL,
  STEP      NUMBER(5)                           NOT NULL,
  MESSAGE   VARCHAR2(2000 BYTE)                 NOT NULL
) ;

