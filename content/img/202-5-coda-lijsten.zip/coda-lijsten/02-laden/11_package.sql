/*******************************************************************************
 * file:
 * auth: dirk postma
 * date: 3 dec 2008
 * desc: onderhouden default rechter/linkerlijsten bij elementen
 ********************************************************************************/


CREATE OR REPLACE PACKAGE CODA.p_lee_update_rllists
AS
   PROCEDURE werkbij;
END;
/


CREATE OR REPLACE PACKAGE BODY CODA.P_LEE_UPDATE_RLLISTS

AS
-- package variabelen ----------------------------------------------------------
v_run     NUMBER ;
err_num   NUMBER ;
err_msg   VARCHAR2(2000);


/*******************************************************************************
procedure: log_init
desc:      voor ophalen van een run nummer
*******************************************************************************/
PROCEDURE log_init AS
    v_step                    NUMBER;
BEGIN
   /* volgende runnr. */
   SELECT s_lee_hierarchieen_run.NEXTVAL INTO v_run FROM DUAL ;

   /* stapnr resetten */
   SELECT 0 - s_lee_hierarchieen_step.NEXTVAL INTO v_step FROM DUAL ;
   EXECUTE IMMEDIATE ' ALTER SEQUENCE s_LEE_HIERARCHIEEN_STEP INCREMENT BY ' || v_step ;
   SELECT s_lee_hierarchieen_step.NEXTVAL INTO v_step FROM DUAL ;
   EXECUTE IMMEDIATE ' ALTER SEQUENCE s_LEE_HIERARCHIEEN_STEP INCREMENT BY  1 ' ;

END log_init ;

/*******************************************************************************
procedure: log_write
*******************************************************************************/
PROCEDURE log_write (
   p_message                VARCHAR2
)
AS
   v_step                   NUMBER ;
   PRAGMA AUTONOMOUS_TRANSACTION;   -- commit van de logging moet afzonderlijk gebeuren
BEGIN
   /* volgende stap nummer ophalen */
   SELECT s_lee_hierarchieen_step.NEXTVAL INTO v_step FROM DUAL ;

   INSERT INTO t_lee_hierarchieen_log VALUES (v_run, SYSDATE, v_step, p_message) ;
   COMMIT ;
EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20100, '  *** probleem met opslaan login ***  ' ||
         to_char(sysdate) || '+' || v_run || '+' || v_step || '+' || p_message);
END ;

/*******************************************************************************
procedure: werbij, update de lijsten bij de elementen
*******************************************************************************/
PROCEDURE werkbij
AS

-- cursor voor doorlopen van de bedrijven
cursor    c_cmp
is
select    c.code
from      oas_company c
where     c.deldate is null
   and    c.code in ('WRK', 'BGR', 'VPL') ;

-- cursor voor doorlopen relevante elementen -----------------------------------
cursor    c_elm (p_cmpcode in varchar2)
is
select    e.cmpcode
,         e.elmlevel
,         e.code
,         'DUMMY1RECHTERLIJST' || substr(l.grpcode, -3) as groep
from      oas_grplist l
,         oas_element e
where     e.cmpcode  = l.cmpcode
   and    e.elmlevel = l.elmlevel
   and    e.code     = l.code
   and    l.grpcode  like 'D1L%'   -- selecteer alleen de elementen met een Dummy RL groep
   and    e.cmpcode  = p_cmpcode
   and    e.elmlevel = 1
   and    e.deldate  is null
order by  1, 2, 3 ;

BEGIN
   log_init ;

   LOG_WRITE('****** Start procedure: werkbij ******') ;

   for r_cmp in c_cmp loop
      LOG_WRITE('**** Bedrijf: ' || r_cmp.code || ' ****') ;

       FOR r_elm IN c_elm (r_cmp.code) LOOP
          -- oude lijst verwijderen
          LOG_WRITE('*** Element: ' || r_elm.cmpcode || '/' || r_elm.elmlevel || '/' || r_elm.code ||
             ', dummy:' || r_elm.groep || ' ***') ;
          DELETE
          FROM      oas_rllist
          WHERE     cmpcode  = r_elm.cmpcode
             AND    elmlevel = r_elm.elmlevel
             AND    elmcode  = r_elm.code ;
          LOG_WRITE('Oude regels verwijderd, aantal: ' || SQL%ROWCOUNT);

          -- nieuwe lijst toevoegen
          INSERT INTO oas_rllist
          SELECT    r_elm.cmpcode
          ,         r_elm.code
          ,         r_elm.elmlevel
          ,         t.DIRECTION, t.LSTSEQNO, t.LOGICAL, t.OPENB, t.VOCAB, t.CFFUNCTION, t.CFVALUE, t.CLOSEB, t.IVAL
          FROM      oas_rllist t
          WHERE     t.cmpcode  = r_elm.cmpcode
             AND    t.elmlevel = r_elm.elmlevel
             AND    t.elmcode  = r_elm.groep ;
          LOG_WRITE('Nieuwe regels toegevoegd, aantal: ' || SQL%ROWCOUNT);

       END LOOP ;

      LOG_WRITE('**** Einde bedrijf: ' || r_cmp.code || ' ****') ;
   end loop ;

   commit ;

   LOG_WRITE('****** Einde procedure: werkbij ******') ;
EXCEPTION
   WHEN OTHERS THEN
      err_num := SQLCODE ;
      err_msg := SQLERRM ;
      log_write('Probleem: ' || LTRIM(TO_CHAR(err_num)) || ', ' || err_msg) ;
      log_write('****** Abnormaal einde ******') ;
      ROLLBACK ;

END werkbij ;

end ;
/* eof ************************************************************************/

