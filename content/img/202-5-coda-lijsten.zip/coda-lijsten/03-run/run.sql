/*******************************************************************************
file:
date: december 2008
auth: dpa
desc: uitvoeren procedure voor updaten standaard RL lijsten
*******************************************************************************/

SPOOL     run.log

CONNECT   coda/<passwd>@tcoda

SELECT    TO_CHAR(SYSDATE, 'YYYYMMDD HH24:MI:SS') begin FROM DUAL ;

execute   p_lee_update_rllists.werkbij ;

SELECT    TO_CHAR(SYSDATE, 'YYYYMMDD HH24:MI:SS') einde FROM DUAL ;

SPOOL     OFF

exit

/* einde script */
