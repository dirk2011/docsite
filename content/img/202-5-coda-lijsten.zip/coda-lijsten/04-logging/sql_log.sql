/*******************************************************************************
file:
desc: toon laatste logging
date: augustus 2005
auth: dpa
*******************************************************************************/

CONNECT   coda/<passwd>@tcoda

set       pagesize 9999
set       linesize 150

column    message   format a80

spool     sql_log.log


select    run, step, to_char(run_date, 'YYYY-MM-DD HH24:MI:SS') time, message
from      t_lee_hierarchieen_log
where     run =
         (select max(run) from t_lee_hierarchieen_log)
order by  step ;


spool     off

exit

/* einde */
